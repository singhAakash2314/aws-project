# -*- coding: utf-8 -*-



aws_access_key_id='ASIASDY4MWMWH4I5666N'
aws_secret_access_key='nHb0m8mdSrTFc+6146nvrH1UQLnzd/K6ZkqbXpPp'
aws_session_token='FwoGZXIvYXdzELr//////////wEaDE6Nbbun/Vz7sN+lvyLVAZ+g+CX4SPTl8woqScvnNXXQFCYXx1aMianZR1iYcC18u8zDIHs7rLnzuEKsu7ooJAq0viumac2TI18NwuOpkq1Xo8XTNmPrlnKGMq46asgErp2/VXPtsChcKosD5B3bBzTMoCj94GovATfwsDnoe+GzjD7STtfhcXbYOZvYifp+BlrADPbWY5iJW0n9uz8slkTR08cVILMNJzW3OAPjo3P18JFxQY/j1IH7QaNCqat85DyeLXxTsHLLTY1rdEeiN7l1OuOJG8WLh4xpz2TmpAcsbd/cOSjdk+acBjItOk2bDUJhJPYB3sXXpDp7W5nI9m8Zyn0eJeGuicSv/omtCPFWxkl6a5/9NkpG'
#BUCKET_NAME='eat-sure'